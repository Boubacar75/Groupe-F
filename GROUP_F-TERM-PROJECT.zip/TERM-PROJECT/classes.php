<html>
  
<head> 

	<title> Registration Page</title>
<link href="stylesheet.css" rel="stylesheet">
<style type="text/css">
	table{
		border-collapse: collapse;
		width: 100%;
		color: white;
		font-family: monospace;
		font-size: 20px;
		text-align: left;
	}

	th{
		background-color: green;
		color: black;
	}
	tr:nth-child(even){background-color: #4d0026;}
</style>
 </head>
<body>
	<table>
<?php


$servername="localhost";
$username="root";
$password="";

$choice=$_REQUEST['cn'];


echo" YOUR QUERY STRING SEARCH RESULT"."<br>";

$conn = mysqli_connect($servername, $username, $password);

if (!$conn)
 { 
die("Connection failed: ". mysqli_connect_error());
}
 // Send the query to the database
	
		$query="select * from termproject.schedule where Room ='".$choice."'";
				$result = mysqli_query($conn, $query);
						include('classgrid.html');
					echo "<br>";
					
					echo"  <tr>
							<th> hours </th>
							<th> Monday </th>
							<th> Tuesday </th>
							<th> Wednesday </th>
							<th> Thursday </th>
							<th> Friday </th>
							<th> Saturday </th>
							<th> Sunday </th>
							</tr>";
					if (mysqli_num_rows($result) > 0) // if there are rows present
					{
					while($row = mysqli_fetch_assoc($result))
					 { // fetch next row
					echo "<tr><td>"
					.$row["hours"]."</td><td>"
					.$row["monday"]."</td><td>"
					.$row["tuesday"]."</td><td>"
					.$row["wednesday"]."</td><td>"
					.$row["thursday"]."</td><td>"
					.$row["friday"]."</td><td>"
					.$row["saturday"]."</td><td>"
					.$row["sunday"]."</td></tr>";
					 // output data of that row
					}
						echo "</table>";
					} 

					else {
					echo "No results";
					}
					mysqli_free_result($result);
					$conn->close();
			


?>
</table>
</body>
</html>				