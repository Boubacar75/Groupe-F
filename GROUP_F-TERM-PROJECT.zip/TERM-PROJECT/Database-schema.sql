-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 24, 2020 at 03:29 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `termproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `timetable`
--

CREATE TABLE `timetable` (
  `ID` int(11) NOT NULL,
  `hours` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `timetable`
--

INSERT INTO `timetable` (`ID`, `hours`) VALUES
(1, '8am-9am'),
(2, '9am-10pm'),
(3, '10am-11am'),
(4, '11am-12pm'),
(5, '12pm-1pm'),
(6, '1pm-2pm'),
(7, '2pm-3pm'),
(8, '3pm-4pm'),
(9, '4pm-5pm'),
(10, '5pm-6pm'),
(11, '6pm-7pm'),
(12, '7pm-8pm'),
(13, '8pm-9pm'),
(14, '9pm-10pm'),
(15, '8am-9am'),
(16, '9am-10am'),
(17, '10am-11am'),
(18, '11am-12pm'),
(19, '12pm-1pm'),
(20, '1pm-2pm'),
(21, '2pm-3pm'),
(22, '3pm-4pm'),
(23, '4pm-5pm'),
(24, '5pm-6pm'),
(25, '6pm-7pm'),
(26, '7pm-8pm'),
(27, '8pm-9pm'),
(28, '9pm-10pm'),
(29, '9am-10am'),
(30, '10am-11am'),
(31, '11am-12pm'),
(32, '12pm-1pm'),
(33, '1pm-2pm'),
(34, '2pm-3pm'),
(35, '3pm-4pm'),
(36, '4pm-5pm'),
(37, '5pm-6pm'),
(38, '6pm-7pm'),
(39, '7pm-8pm'),
(40, '8pm-9pm'),
(41, '9pm-10pm'),
(42, '9am-10am'),
(43, '11am-12pm'),
(44, '12pm-1pm'),
(45, '1pm-2pm'),
(46, '2pm-3pm'),
(47, '3pm-4pm'),
(48, '4pm-5pm'),
(49, '5pm-6pm'),
(50, '6pm-7pm'),
(51, '7pm-8pm'),
(52, '8pm-9pm'),
(53, '9pm-10pm'),
(54, '8am-9am'),
(55, '9am-10am'),
(56, '10am-11am'),
(57, '11am-12pm'),
(58, '12pm-1pm'),
(59, '1pm-2pm'),
(60, '2pm-3pm'),
(61, '3pm-4pm'),
(62, '4pm-5pm'),
(63, '5pm-6pm'),
(64, '6pm-7pm'),
(65, '7pm-8pm'),
(66, '8pm-9pm'),
(67, '9pm-10pm'),
(68, '8am-9am'),
(69, '9am-10am'),
(70, '10am-11am'),
(71, '11am-12pm'),
(72, '12pm-1pm'),
(73, '1pm-2pm'),
(74, '2pm-3pm'),
(75, '3pm-4pm'),
(76, '4pm-5pm'),
(77, '5pm-6pm'),
(78, '6pm-7pm'),
(79, '7pm-8pm'),
(80, '8pm-9pm'),
(81, '9pm-10pm'),
(82, '8am-9am'),
(83, '9am-10am'),
(84, '10am-11am'),
(85, '11am-12pm'),
(86, '12pm-1pm'),
(87, '1pm-2pm'),
(88, '2pm-3pm'),
(89, '3pm-4pm'),
(90, '4pm-5pm'),
(91, '5pm-6pm'),
(92, '6pm-7pm'),
(93, '7pm-8pm'),
(94, '8pm-9pm'),
(95, '9pm-10pm'),
(96, '10am-11am'),
(97, '11am-12pm'),
(98, '12pm-1pm'),
(99, '2pm-3pm'),
(100, '3pm-4pm'),
(101, '4pm-5pm'),
(102, '5pm-6pm'),
(103, '6pm-7pm'),
(104, '7pm-8pm'),
(105, '8pm-9pm'),
(106, '9pm-10pm'),
(107, '11am-12pm'),
(108, '1pm-2pm'),
(109, '5pm-6pm'),
(110, '6pm-7pm'),
(111, '7pm-8pm'),
(112, '9pm-10pm'),
(113, '8am-9am'),
(114, '9am-10am'),
(115, '11am-12pm'),
(116, '12pm-1pm'),
(117, '1pm-2pm'),
(118, '2pm-3pm'),
(119, '4pm-5pm'),
(120, '5pm-6pm'),
(121, '6pm-7pm'),
(122, '7pm-8pm'),
(123, '9pm-10pm');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `timetable`
--
ALTER TABLE `timetable`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `timetable`
--
ALTER TABLE `timetable`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=124;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
