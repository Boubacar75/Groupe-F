-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 15, 2020 at 11:14 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `termproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `classschedule`
--

CREATE TABLE `classschedule` (
  `Room` char(6) NOT NULL,
  `courseNo` char(6) NOT NULL,
  `SectionNo` char(6) DEFAULT NULL,
  `monday` varchar(45) DEFAULT NULL,
  `tuesday` varchar(45) DEFAULT NULL,
  `wednesday` varchar(45) DEFAULT NULL,
  `thursday` varchar(45) DEFAULT NULL,
  `friday` varchar(45) DEFAULT NULL,
  `saturday` varchar(45) DEFAULT NULL,
  `sunday` varchar(45) DEFAULT NULL,
  `total hours` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `classschedule`
--

INSERT INTO `classschedule` (`Room`, `courseNo`, `SectionNo`, `monday`, `tuesday`, `wednesday`, `thursday`, `friday`, `saturday`, `sunday`, `total hours`) VALUES
('F904', 'CIS100', '1200', '8am-10am', '', '8am-10am', '', '', '', '', '4'),
('F908', 'CIS115', '1104', '10am-12pm', '', '10am-12pm', '', '', '', '', '4'),
('F904', 'CIS120', '1704', '12pm-2pm', '', '12pm-1pm', '', '', '', '', '3'),
('F905', 'CIS140', '1802', '2pm-4pm', '', '4pm-5pm', '', '', '', '', '3'),
('M1209', 'CIS155', '1600', '4pm-7pm', '', '5pm-7pm', '', '', '', '', '5'),
('F904', 'CIS160', '1105', '7pm-9pm', '', '7pm-8pm', '', '', '', '', '3'),
('F1204', 'CIS165', '1404', '', '8am-10am', '', '8am-10am', '', '', '', '4'),
('F1201', 'CIS180', '1303', '', '10am-12pm', '', '10am-12pm', '', '', '', '4'),
('F1113', 'CIS200', '1504', '', '12pm-2pm', '', '12pm-2pm', '', '', '', '4'),
('F1203', 'CIS207', '1103', '', '8am-10am', '', '8am-10am', '2pm-4pm', '', '', '6'),
('F905', 'CIS220', '1603', '', '2pm-4pm', '', '2pm-4pm', '', '', '', '4'),
('F1113', 'CIS235', '1505', '', '10am-13pm', '', '10am-12pm', '', '', '', '5'),
('M1209', 'CIS255', '1705', '', '10am-1pm', '', '10am-1pm', '', '', '', '6'),
('F906', 'CIS280', '1301', '', '10am-12pm', '', '10am-12pm', '', '', '', '4'),
('F1204', 'CIS316', '1001', '', '4pm-6pm', '', '4pm-6pm', '', '', '', '4'),
('F907', 'CIS317', '1801', '', '7pm-9pm', '', '7pm-9pm', '', '', '', '4'),
('F1204', 'CIS325', '1902', '', '1pm-3pm', '', '1pm-3pm', '', '', '', '4'),
('M1209', 'CIS335', '1002', '', '3pm-6pm', '', '3pm-5pm', '', '', '', '5'),
('F1203', 'CIS345', '1201', '', '6pm-9pm', '', '5pm-7pm', '', '', '', '5'),
('F907', 'CIS359', '1904', '8am-10am', '', '', '', '', '', '', '4'),
('F904', 'CIS362', '1601', '', '', '', '', '8am-12am', '', '', '4'),
('F906', 'CIS364', '1203', '10am-12pm', '', '', '10am-12pm', '', '', '', '4'),
('F1201', 'CIS365', '1502', '3pm-6pm', '', '', '3pm-6pm', '', '', '', '5'),
('F905', 'CIS370', '1304', '', '8am-10am', '', '8am-10am', '', '', '', '4'),
('F907', 'CIS385', '1803', '12pm-2pm', '', '12pm-2pm', '', '', '', '', '4'),
('F1113', 'CIS390', '1602', '', '', '', '', '8am-12am', '', '', '4'),
('F1203', 'CIS395', '1305', '6pm-9pm', '', '', '5pm-7pm', '', '', '', '5'),
('F906', 'CIS420', '1905', '', '4pm-7pm', '', '4pm-6pm', '', '', '', '5'),
('M1209', 'CIS440', '1003', '', '', '', '', '8am-12pm', '', '', '4'),
('F1204', 'CIS445', '1302', '', '7pm-10pm', '', '6pm-8pm', '', '', '', '5'),
('F1201', 'CIS455', '1804', '6pm-9pm', '', '6pm-8pm', '', '', '', '', '5'),
('F908', 'CIS459', '1405', '6pm-9pm', '', '5pm-8pm ', '', '', '', '', '5'),
('F906', 'CIS465', '1202', '6pm-9pm', '', '5pm-9pm ', '', '5pm-8pm', '', '', '10'),
('F1204', 'CIS475', '1000', '6pm-9pm', '', '6pm-8pm', '', '', '', '', '5'),
('F1113', 'CIS480', '1903', '', '', '', '', '12pm-3pm', '', '', '3'),
('M1209', 'CIS485', '1800', '', '', '', '', '12pm-4pm', '', '', '4'),
('F1203', 'CIS490', '1403', '', '', '', '', '10am-2pm', '', '', '4'),
('F907', 'CIS495', '1503', '', '', '', '', '8am-12pm', '', '', '4'),
('F904', 'CSC 10', '1500', '', '8am-10am', '', '8am-10am', '', '', '', '4'),
('F905', 'CSC 11', '1901', '', '10am-1pm', '', '10am-12pm', '', '', '', '5'),
('F906', 'CSC111', '1900', '', '1pm-4pm', '', '12pm-2pm', '', '', '', '5'),
('F907', 'csc210', '1700', '', '4pm-7pm', '', '2pm-4pm', '', '', '', '5'),
('M1209', 'CSC211', '1100', '', '7pm-10pm', '', '4pm-6pm', '', '', '', '5'),
('F908', 'CSC215', '1101', '', '', '', '6pm-10pm', '', '', '', '4'),
('F1113', 'CSC230', '1701', '8am-11am', '', '8am-11am', '', '', '', '', '6'),
('F1201', 'CSC231', '1400', '11am-1pm', '', '11am-1pm', '', '', '', '', '4'),
('F1203', 'CSC310', '1702', '1pm-3pm', '', '4pm-6pm', '', '', '', '', '4'),
('F1204', 'CSC330', '1703', '3pm-5pm', '', '6pm-8pm', '', '', '', '', '4'),
('F904', 'CSC331', '1401', '10am-13pm', '', '10am-12pm', '', '', '', '', '5'),
('M1209', 'CSC350', '1300', '5pm-8pm', '', '8pm-10pm', '', '', '', '', '5'),
('F906', 'CSC410', '1102', '', '', '', '', '8am-12pm', '', '', '4'),
('F1201', 'CSC430', '1402', '8am-10am', '', '8am-10am', '', '', '', '', '4'),
('F1113', 'CSC450', '1603', '1pm-3pm', '', '12pm-2pm', '', '', '', '', '4'),
('F908', 'CSC470', '1501', '3pm-6pm', '', '4pm-6-pm', '', '', '', '', '5');

-- --------------------------------------------------------

--
-- Table structure for table `courseinformation`
--

CREATE TABLE `courseinformation` (
  `courseNo` char(6) NOT NULL,
  `Title` varchar(55) DEFAULT NULL,
  `credit` int(11) DEFAULT NULL,
  `sectionNo` char(4) NOT NULL,
  `room` char(6) DEFAULT NULL,
  `instructor` varchar(55) DEFAULT NULL,
  `email` varchar(55) DEFAULT NULL,
  `position` varchar(55) DEFAULT NULL,
  `phone` varchar(55) DEFAULT NULL,
  `hours` varchar(55) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `courseinformation`
--

INSERT INTO `courseinformation` (`courseNo`, `Title`, `credit`, `sectionNo`, `room`, `instructor`, `email`, `position`, `phone`, `hours`) VALUES
('CIS100', 'Introduction to Computer Applications', 3, '1200', 'F904', 'Errera,Aberto', 'aerrera@bmcc.cuny.edu', 'Faculty', '212-220-1483', '4'),
('CIS115', 'Introduction to Computer and Information Security', 3, '1104', 'F908', 'O\' Sullivan,John T', '', 'Adjunct', '212-220-1476', '4'),
('CIS120', 'Introduction to Data Base Applications', 2, '1704', 'F904', 'Chen,Yan', 'ychen@bmcc.cuny.edu', 'Faculty', '212-220-8384', '3'),
('CIS140', 'Introduction to Spreadsheet Applications', 2, '1802', 'F905', 'Melie,Ora K', '', 'Adjunct', '212-220-1476', '3'),
('CIS155', 'Computer Hardware', 4, '1600', 'M1209', 'Avcilar,Tamer', 'tavcilar@bmcc.cuny.edu', 'Faculty', '212-220-1478', '5'),
('CIS160', 'Desktop Publishing Packages', 2, '1105', 'F904', 'Toliyat Abolhassani,Amir Mohsen', '', 'Adjunct', '212-220-1476', '3'),
('CIS165', 'Introduction to Operating Systems', 3, '1404', 'F1204', 'Azhar,Mohammad Quamrul', 'mazhar@bmcc.cuny.edu', 'Faculty', '212-220-1477', '4'),
('CIS180', 'Introduction to the Internet', 3, '1303', 'F1201', 'Jayaweera,Darshani P', '', 'Adjunct', '212-220-1476', '4'),
('CIS200', 'Introduction Systems and Technologies', 3, '1504', 'F1113', 'Hernandez,Candido', '', 'Adjunct', '212-220-1476', '4'),
('CIS207', 'Healthcare Information Technologies and Management Syst', 4, '1103', 'F1203', 'Harricharan,Andy L', '', 'Adjunct', '212-220-1476', '6'),
('CIS220', 'Visual BASIC', 3, '1603', 'F905', 'Zeidan,Ayman I', '', 'Adjunct', '212-220-1476', '4'),
('CIS235', 'Computer Operations I', 4, '1505', 'F1113', 'Kalicharan,Dharamraj', '', 'Adjunct', '212-220-1476', '5'),
('CIS255', 'Computer Software', 3, '1705', 'M1209', 'Patrick,Dexter', '', 'Adjunct', '212-220-1476', '6'),
('CIS280', 'Advanced Internet Applications', 3, '1301', 'F906', 'Kalicharan,Dharamraj', '', 'Adjunct', '212-220-1476', '4'),
('CIS316', 'Introduction to Digital Forensics', 3, '1001', 'F1204', 'Veyler,Mikhail', '', 'Adjunct', '212-220-1476', '4'),
('CIS317', 'Introduction to Cryptography', 4, '1801', 'F907', 'Adesman,Alexander', '', 'Adjunct', '212-220-1476', '4'),
('CIS325', 'Systems Analysis', 3, '1902', 'F1204', 'Rani,Chigurupati S', 'csrani@bmcc.cuny.edu', 'Faculty', '212-220-1487', '4'),
('CIS335', 'Computer Operations II/ JCL', 3, '1002', 'M1209', 'Khan,Lawrence', '', 'Adjunct', '212-220-1476', '5'),
('CIS345', 'Telecommunication Networks I', 3, '1201', 'F1203', 'Nossa,George A', '', 'Adjunct', '212-220-1476', '5'),
('CIS359', 'Information Assurance', 3, '1904', 'F907', 'Scheiman,Arnold J', 'ascheiman@bmcc.cuny.edu', 'Faculty', '212-220-7227', '4'),
('CIS362', 'Cloud Computing', 3, '1601', 'F904', 'Liu,Ligon Mengxu', '', 'Adjunct', '212-220-1476', '4'),
('CIS364', 'Mobile Device Programming', 3, '1203', 'F906', 'Mokal,Prajakta L', '', 'Adjunct', '212-220-1476', '4'),
('CIS365', 'Business Systems I', 4, '1502', 'F1201', 'Genis,Yakov', 'ygenis@bmcc.cuny.edu', 'Faculty', '212-220-1482', '5'),
('CIS370', 'Database Driven Website Programming', 3, '1304', 'F905', 'Hasan,Naushad', '', 'Adjunct', '212-220-1476', '4'),
('CIS385', 'Web Programming I', 3, '1803', 'F907', 'Naranjo Rivera,Eduardo Efrain', '', 'Adjunct', '212-220-1476', '4'),
('CIS390', 'Wireless Programming', 3, '1602', 'F1113', 'Vargas,Jose I', 'jvargas@bmcc.cuny.edu', 'Faculty', '212-220-1481', '4'),
('CIS395', 'Database Systems I', 3, '1305', 'F1203', 'Conroy,Matthew', '', 'Adjunct', '212-220-1476', '5'),
('CIS420', 'Systems Implementation', 3, '1905', 'F906', 'Cooper,Kenneth J', '', 'Adjunct', '212-220-1476', '5'),
('CIS440', 'UNIX', 3, '1003', 'M1209', 'Vargas,Jose', 'jvargas@bmcc.cuny.edu', 'Faculty', '212-220-1481', '4'),
('CIS445', 'Telecommunications Networks II / LAN', 3, '1302', 'F1204', 'Melie,Ora K', '', 'Adjunct', '212-220-1476', '5'),
('CIS455', 'Network Security', 3, '1804', 'F1201', 'Sana,Ajaz', '', 'Adjunct', '212-220-1476', '5'),
('CIS459', 'Ethical Hacking and System Defense', 3, '1405', 'F908', 'Nossa,George A', '', 'Adjunct', '212-220-1476', '5'),
('CIS465', 'Business Systems II', 3, '1202', 'F906', 'O\'Faire,Lashawna R', '', 'Adjunct', '212-220-1476', '10'),
('CIS475', 'Wireless Information Networks', 4, '1000', 'F1204', 'Lau,Roy', '', 'Adjunct', '212-220-1476', '5'),
('CIS480', 'Operating Systems Concepts', 3, '1903', 'F1113', 'Hernandez,Candido', '', 'Adjunct', '212-220-1476', '3'),
('CIS485', 'Web Programming II', 3, '1800', 'M1209', 'Naranjo Rivera,Eduardo Efrain', '', 'Adjunct', '212-220-1476', '4'),
('CIS490', 'Introduction to Data Science', 3, '1403', 'F1203', 'Doumassi,Kokou', '', 'Adjunct', '212-220-1476', '4'),
('CIS495', 'Database Systems II', 3, '1503', 'F907', 'Zeidan,Ayman', '', 'Adjunct', '212-220-1476', '4'),
('CSC101', 'Principles in Information Technology and Computation', 3, '1500', 'F904', 'Hasan,Naushad', '', 'Adjunct', '212-220-1476', '4'),
('CSC110', 'Computer Programming I', 4, '1901', 'F905', 'Scheiman,Arnold', 'ascheiman@bmcc.cuny.edu', 'Faculty', '212-220-7227', '5'),
('CSC111', 'Introduction to Programming ', 4, '1900', 'F906', 'Chan,Matthew', 'machan@bmcc.cuny.edu', 'Faculty', '212-776-7228', '5'),
('csc210', 'Computer Programming  II', 3, '1700', 'F907', 'Yan,Louise', '', 'Adjunct', '212-220-1476', '5'),
('CSC211', 'Advanced Programming Techiques', 3, '1100', 'M1209', 'Azhar ,Mohammed Quamrul', 'mazhar@bmcc.cuny.edu', 'Faculty', '212-220-1477', '5'),
('CSC215', 'Fundamental of Computer Systems.', 3, '1101', 'F908', 'Avcilar ,Tamer', 'tavcilar@bmcc.cuny.edu', 'Faculty', '212-220-1478', '4'),
('CSC230', 'Discrete Structures', 3, '1701', 'F1113', 'Adesman,Alexander', '', 'Adjunct', '212-220-1476', '6'),
('CSC231', 'Discrete Structures and Application to Computer Science', 4, '1400', 'F1201', 'Eckman,Robert L', '', 'Adjunct', '212-220-1476', '4'),
('CSC310', 'Assembler Language Architecture I', 3, '1702', 'F1203', 'Veyler,Mikhail', '', 'Adjunct', '212-220-1476', '4'),
('CSC330', ' Data Structures I', 3, '1703', 'F1204', 'Salvati,Anna', 'asalvati@bmcc.cuny.edu', 'Faculty', '212-220-1480', '4'),
('CSC331', 'Data Structures ', 3, '1401', 'F904', 'Anderson,Raheim Alan', '', 'Adjunct', '212-220-1476', '5'),
('CSC350', 'Software Development ', 3, '1300', 'M1209', 'Wei,Ching', 'cwei@bmcc.cuny.edu', '', '212-220-8385', '5'),
('CSC410', 'Assembler Language Architecture II', 3, '1102', 'F906', 'Ye,Ze', '', 'Adjunct', '212-220-1476', '4'),
('CSC430', 'Data Structures II', 3, '1402', 'F1201', 'Kok,Ahmet', 'amkok@bmcc.cuny.edu', 'Faculty', '212-220-1492', '4'),
('CSC450', 'Computer Graphics', 3, '1603', 'F1113', 'Chen,Danny', '', 'Adjunct', '212-220-1492', '4'),
('CSC470', 'Mathematical Foundations of Computer (Same as MAT 470)', 4, '1501', 'F908', 'Santos,Jose Ramon R', '', 'Adjunct', '212-220-1476', '5');

-- --------------------------------------------------------

--
-- Table structure for table `coursesection`
--

CREATE TABLE `coursesection` (
  `courseNo` char(6) NOT NULL,
  `sectionNo` char(4) DEFAULT NULL,
  `room` char(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `coursesection`
--

INSERT INTO `coursesection` (`courseNo`, `sectionNo`, `room`) VALUES
('CIS100', '1200', 'F904'),
('CIS115', '1104', 'F908'),
('CIS120', '1704', 'F904'),
('CIS140', '1802', 'F905'),
('CIS155', '1600', 'M1209'),
('CIS160', '1105', 'F904'),
('CIS165', '1404', 'F1204'),
('CIS180', '1303', 'F1201'),
('CIS200', '1504', 'F1113'),
('CIS207', '1103', 'F1203'),
('CIS220', '1603', 'F905'),
('CIS235', '1505', 'F1113'),
('CIS255', '1705', 'M1209'),
('CIS280', '1301', 'F906'),
('CIS316', '1001', 'F1204'),
('CIS317', '1801', 'F907'),
('CIS325', '1902', 'F1204'),
('CIS335', '1002', 'M1209'),
('CIS345', '1201', 'F1203'),
('CIS359', '1904', 'F907'),
('CIS362', '1601', 'F904'),
('CIS364', '1203', 'F906'),
('CIS365', '1502', 'F1201'),
('CIS370', '1304', 'F905'),
('CIS385', '1803', 'F907'),
('CIS390', '1602', 'F1113'),
('CIS395', '1305', 'F1203'),
('CIS420', '1905', 'F906'),
('CIS440', '1003', 'M1209'),
('CIS445', '1302', 'F1204'),
('CIS455', '1804', 'F1201'),
('CIS459', '1405', 'F908'),
('CIS465', '1202', 'F906'),
('CIS475', '1000', 'F1204'),
('CIS480', '1903', 'F1113'),
('CIS485', '1800', 'M1209'),
('CIS490', '1403', 'F1203'),
('CIS495', '1503', 'F907'),
('CSC101', '1500', 'F904'),
('CSC110', '1901', 'F905'),
('CSC111', '1900', 'F906'),
('csc210', '1700', 'F907'),
('CSC211', '1100', 'M1209'),
('CSC215', '1101', 'F908'),
('CSC230', '1701', 'F1113'),
('CSC231', '1400', 'F1201'),
('CSC310', '1702', 'F1203'),
('CSC330', '1703', 'F1204'),
('CSC331', '1401', 'F904'),
('CSC350', '1300', 'M1209'),
('CSC410', '1102', 'F906'),
('CSC430', '1402', 'F1201'),
('CSC450', '1603', 'F1113'),
('CSC470', '1501', 'F908');

-- --------------------------------------------------------

--
-- Table structure for table `instructor`
--

CREATE TABLE `instructor` (
  `instructor_name` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `position` varchar(45) DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL,
  `sectionNo` char(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `instructor`
--

INSERT INTO `instructor` (`instructor_name`, `email`, `position`, `phone`, `sectionNo`) VALUES
('Errera,Aberto', 'aerrera@bmcc.cuny.edu', 'Faculty', '212-220-1483', '1200'),
('O\' Sullivan,John T', '', 'Adjunct', '212-220-1476', '1104'),
('Chen,Yan', 'ychen@bmcc.cuny.edu', 'Faculty', '212-220-8384', '1704'),
('Melie,Ora K', '', 'Adjunct', '212-220-1476', '1802'),
('Avcilar,Tamer', 'tavcilar@bmcc.cuny.edu', 'Faculty', '212-220-1478', '1600'),
('Toliyat Abolhassani,Amir Mohsen', '', 'Adjunct', '212-220-1476', '1105'),
('Azhar,Mohammad Quamrul', 'mazhar@bmcc.cuny.edu', 'Faculty', '212-220-1477', '1404'),
('Jayaweera,Darshani P', '', 'Adjunct', '212-220-1476', '1303'),
('Hernandez,Candido', '', 'Adjunct', '212-220-1476', '1504'),
('Harricharan,Andy L', '', 'Adjunct', '212-220-1476', '1103'),
('Zeidan,Ayman I', '', 'Adjunct', '212-220-1476', '1603'),
('Kalicharan,Dharamraj', '', 'Adjunct', '212-220-1476', '1505'),
('Patrick,Dexter', '', 'Adjunct', '212-220-1476', '1705'),
('Kalicharan,Dharamraj', '', 'Adjunct', '212-220-1476', '1301'),
('Veyler,Mikhail', '', 'Adjunct', '212-220-1476', '1001'),
('Adesman,Alexander', '', 'Adjunct', '212-220-1476', '1801'),
('Rani,Chigurupati S', 'csrani@bmcc.cuny.edu', 'Faculty', '212-220-1487', '1902'),
('Khan,Lawrence', '', 'Adjunct', '212-220-1476', '1002'),
('Nossa,George A', '', 'Adjunct', '212-220-1476', '1201'),
('Scheiman,Arnold J', 'ascheiman@bmcc.cuny.edu', 'Faculty', '212-220-7227', '1904'),
('Liu,Ligon Mengxu', '', 'Adjunct', '212-220-1476', '1601'),
('Mokal,Prajakta L', '', 'Adjunct', '212-220-1476', '1203'),
('Genis,Yakov', 'ygenis@bmcc.cuny.edu', 'Faculty', '212-220-1482', '1502'),
('Hasan,Naushad', '', 'Adjunct', '212-220-1476', '1304'),
('Naranjo Rivera,Eduardo Efrain', '', 'Adjunct', '212-220-1476', '1803'),
('Vargas,Jose I', 'jvargas@bmcc.cuny.edu', 'Faculty', '212-220-1481', '1602'),
('Conroy,Matthew', '', 'Adjunct', '212-220-1476', '1305'),
('Cooper,Kenneth J', '', 'Adjunct', '212-220-1476', '1905'),
('Vargas,Jose', 'jvargas@bmcc.cuny.edu', 'Faculty', '212-220-1481', '1003'),
('Melie,Ora K', '', 'Adjunct', '212-220-1476', '1302'),
('Sana,Ajaz', '', 'Adjunct', '212-220-1476', '1804'),
('Nossa,George A', '', 'Adjunct', '212-220-1476', '1405'),
('O\'Faire,Lashawna R', '', 'Adjunct', '212-220-1476', '1202'),
('Lau,Roy', '', 'Adjunct', '212-220-1476', '1000'),
('Hernandez,Candido', '', 'Adjunct', '212-220-1476', '1903'),
('Naranjo Rivera,Eduardo Efrain', '', 'Adjunct', '212-220-1476', '1800'),
('Doumassi,Kokou', '', 'Adjunct', '212-220-1476', '1403'),
('Zeidan,Ayman', '', 'Adjunct', '212-220-1476', '1503'),
('Hasan,Naushad', '', 'Adjunct', '212-220-1476', '1500'),
('Scheiman,Arnold', 'ascheiman@bmcc.cuny.edu', 'Faculty', '212-220-7227', '1901'),
('Chan,Matthew', 'machan@bmcc.cuny.edu', 'Faculty', '212-776-7228', '1900'),
('Yan,Louise', '', 'Adjunct', '212-220-1476', '1700'),
('Azhar ,Mohammed Quamrul', 'mazhar@bmcc.cuny.edu', 'Faculty', '212-220-1477', '1100'),
('Avcilar ,Tamer', 'tavcilar@bmcc.cuny.edu', 'Faculty', '212-220-1478', '1101'),
('Adesman,Alexander', '', 'Adjunct', '212-220-1476', '1701'),
('Eckman,Robert L', '', 'Adjunct', '212-220-1476', '1400'),
('Veyler,Mikhail', '', 'Adjunct', '212-220-1476', '1702'),
('Salvati,Anna', 'asalvati@bmcc.cuny.edu', 'Faculty', '212-220-1480', '1703'),
('Anderson,Raheim Alan', '', 'Adjunct', '212-220-1476', '1401'),
('Wei,Ching', 'cwei@bmcc.cuny.edu', '', '212-220-8385', '1300'),
('Ye,Ze', '', 'Adjunct', '212-220-1476', '1102'),
('Kok,Ahmet', 'amkok@bmcc.cuny.edu', 'Faculty', '212-220-1492', '1402'),
('Chen,Danny', '', 'Adjunct', '212-220-1492', '1603'),
('Santos,Jose Ramon R', '', 'Adjunct', '212-220-1476', '1501'),
('Errera,Aberto', 'aerrera@bmcc.cuny.edu', 'Faculty', '212-220-1483', '1200'),
('O\' Sullivan,John T', '', 'Adjunct', '212-220-1476', '1104'),
('Chen,Yan', 'ychen@bmcc.cuny.edu', 'Faculty', '212-220-8384', '1704'),
('Melie,Ora K', '', 'Adjunct', '212-220-1476', '1802'),
('Avcilar,Tamer', 'tavcilar@bmcc.cuny.edu', 'Faculty', '212-220-1478', '1600'),
('Toliyat Abolhassani,Amir Mohsen', '', 'Adjunct', '212-220-1476', '1105'),
('Azhar,Mohammad Quamrul', 'mazhar@bmcc.cuny.edu', 'Faculty', '212-220-1477', '1404'),
('Jayaweera,Darshani P', '', 'Adjunct', '212-220-1476', '1303'),
('Hernandez,Candido', '', 'Adjunct', '212-220-1476', '1504'),
('Harricharan,Andy L', '', 'Adjunct', '212-220-1476', '1103'),
('Zeidan,Ayman I', '', 'Adjunct', '212-220-1476', '1603'),
('Kalicharan,Dharamraj', '', 'Adjunct', '212-220-1476', '1505'),
('Patrick,Dexter', '', 'Adjunct', '212-220-1476', '1705'),
('Kalicharan,Dharamraj', '', 'Adjunct', '212-220-1476', '1301'),
('Veyler,Mikhail', '', 'Adjunct', '212-220-1476', '1001'),
('Adesman,Alexander', '', 'Adjunct', '212-220-1476', '1801'),
('Rani,Chigurupati S', 'csrani@bmcc.cuny.edu', 'Faculty', '212-220-1487', '1902'),
('Khan,Lawrence', '', 'Adjunct', '212-220-1476', '1002'),
('Nossa,George A', '', 'Adjunct', '212-220-1476', '1201'),
('Scheiman,Arnold J', 'ascheiman@bmcc.cuny.edu', 'Faculty', '212-220-7227', '1904'),
('Liu,Ligon Mengxu', '', 'Adjunct', '212-220-1476', '1601'),
('Mokal,Prajakta L', '', 'Adjunct', '212-220-1476', '1203'),
('Genis,Yakov', 'ygenis@bmcc.cuny.edu', 'Faculty', '212-220-1482', '1502'),
('Hasan,Naushad', '', 'Adjunct', '212-220-1476', '1304'),
('Naranjo Rivera,Eduardo Efrain', '', 'Adjunct', '212-220-1476', '1803'),
('Vargas,Jose I', 'jvargas@bmcc.cuny.edu', 'Faculty', '212-220-1481', '1602'),
('Conroy,Matthew', '', 'Adjunct', '212-220-1476', '1305'),
('Cooper,Kenneth J', '', 'Adjunct', '212-220-1476', '1905'),
('Vargas,Jose', 'jvargas@bmcc.cuny.edu', 'Faculty', '212-220-1481', '1003'),
('Melie,Ora K', '', 'Adjunct', '212-220-1476', '1302'),
('Sana,Ajaz', '', 'Adjunct', '212-220-1476', '1804'),
('Nossa,George A', '', 'Adjunct', '212-220-1476', '1405'),
('O\'Faire,Lashawna R', '', 'Adjunct', '212-220-1476', '1202'),
('Lau,Roy', '', 'Adjunct', '212-220-1476', '1000'),
('Hernandez,Candido', '', 'Adjunct', '212-220-1476', '1903'),
('Naranjo Rivera,Eduardo Efrain', '', 'Adjunct', '212-220-1476', '1800'),
('Doumassi,Kokou', '', 'Adjunct', '212-220-1476', '1403'),
('Zeidan,Ayman', '', 'Adjunct', '212-220-1476', '1503'),
('Hasan,Naushad', '', 'Adjunct', '212-220-1476', '1500'),
('Scheiman,Arnold', 'ascheiman@bmcc.cuny.edu', 'Faculty', '212-220-7227', '1901'),
('Chan,Matthew', 'machan@bmcc.cuny.edu', 'Faculty', '212-776-7228', '1900'),
('Yan,Louise', '', 'Adjunct', '212-220-1476', '1700'),
('Azhar ,Mohammed Quamrul', 'mazhar@bmcc.cuny.edu', 'Faculty', '212-220-1477', '1100'),
('Avcilar ,Tamer', 'tavcilar@bmcc.cuny.edu', 'Faculty', '212-220-1478', '1101'),
('Adesman,Alexander', '', 'Adjunct', '212-220-1476', '1701'),
('Eckman,Robert L', '', 'Adjunct', '212-220-1476', '1400'),
('Veyler,Mikhail', '', 'Adjunct', '212-220-1476', '1702'),
('Salvati,Anna', 'asalvati@bmcc.cuny.edu', 'Faculty', '212-220-1480', '1703'),
('Anderson,Raheim Alan', '', 'Adjunct', '212-220-1476', '1401'),
('Wei,Ching', 'cwei@bmcc.cuny.edu', '', '212-220-8385', '1300'),
('Ye,Ze', '', 'Adjunct', '212-220-1476', '1102'),
('Kok,Ahmet', 'amkok@bmcc.cuny.edu', 'Faculty', '212-220-1492', '1402'),
('Chen,Danny', '', 'Adjunct', '212-220-1492', '1603'),
('Santos,Jose Ramon R', '', 'Adjunct', '212-220-1476', '1501');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `classschedule`
--
ALTER TABLE `classschedule`
  ADD PRIMARY KEY (`courseNo`);

--
-- Indexes for table `courseinformation`
--
ALTER TABLE `courseinformation`
  ADD PRIMARY KEY (`courseNo`);

--
-- Indexes for table `coursesection`
--
ALTER TABLE `coursesection`
  ADD PRIMARY KEY (`courseNo`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
