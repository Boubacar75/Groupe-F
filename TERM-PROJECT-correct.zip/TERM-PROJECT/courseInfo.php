<html>
  
<head> 

	<title> Registration Page</title>
<link href="stylesheet.css" rel="stylesheet">
<style type="text/css">
	table{
		border-collapse: collapse;
		width: 100%;
		color: white;
		font-family: monospace;
		font-size: 20px;
		text-align: left;
	}

	th{
		background-color: green;
		color: black;
	}
	tr:nth-child(even){background-color: #4d0026;}
</style>
 </head>
<body>
	<table>
<?php


$servername="localhost";
$username="root";
$password="";

// let receive cn value from button click
$query=$_REQUEST['cn'];
echo'
<P>
<a href="choice.html" > <button  type="button" class="register_btn"> GO to menu </button></a> </p>';


//connecting to the database

$conn = mysqli_connect($servername, $username, $password);

if (!$conn)
 { 
die("Connection failed: ". mysqli_connect_error());
}
$sql =$query; // variable choice to do if statement

$result = mysqli_query($conn, $sql); // Send the query to the database

//if statement to adjust output


	if($sql=='select * from termproject.schedule')
					{
						echo"classschedule overview"."<br>";
					echo "<br>";
					echo"  <tr>
							<th> ID </th>
							<th> hours </th>
							<th> Monday </th>
							<th> Tuesday </th>
							<th> Wednesday </th>
							<th> Thursday </th>
							<th> Friday </th>
							<th> Saturday </th>
							<th> Sunday </th>
							<th> Room </th>
							</tr>";
					if (mysqli_num_rows($result) > 0) // if there are rows present
					{
					while($row = mysqli_fetch_assoc($result))
					 { // fetch next row
					echo "<tr><td>"
					.$row["ID"]."</td><td>"
					.$row["hours"]."</td><td>"
					.$row["monday"]."</td><td>"
					.$row["tuesday"]."</td><td>"
					.$row["wednesday"]."</td><td>"
					.$row["thursday"]."</td><td>"
					.$row["friday"]."</td><td>"
					.$row["saturday"]."</td><td>"
					.$row["sunday"]."</td><td>"
					.$row["room"]."</td></tr>"; // output data of that row
					}
						echo "</table>";
					} 

					else {
					echo "No results";
					}
					mysqli_free_result($result);
					$conn->close();
					}

else
echo"QUERY STRING ERROR";


					

?>
</table>
</body>
</html>